
'name:code/func.R'
#### functions ####
library(rgeos)
library(rgdal)
library(raster)
library(foreign)
library(sqldf)
library(dplyr)
library(data.table)
library(reshape)
